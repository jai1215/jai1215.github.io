import sys
import math
import random

def getInputDefault():
    number_of_cells = int(input())  # 37
    MAP = []
    for i in range(number_of_cells):
        inps = list(map(int, input().split()))
        M = dict()
        M['idx'] = inps[0]
        M['rich'] = inps[1]
        M['neigh'] = inps[2:]
        MAP.append(M)
    MAP.sort(key=lambda x: x['idx'])
    return MAP

def getInput():
    #Day & Nutrients
    DAY = int(input())
    TIME = DAY % 6
    NUTRIENTS = int(input())
    #SUN & Score
    SUN, SCORE = [int(i) for i in input().split()]
    inps = input().split()
    OPP_SUN = int(inps[0])
    OPP_SCORE = int(inps[1])
    OPP_WAITING = (inps[2] != "0")
    N_TREES = int(input())
    # Trees
    TREE = []
    MY_TREE = []
    OP_TREE = []
    for i in range(N_TREES):
        T = dict()
        inputs = input().split()
        T['idx'] = int(inputs[0])  # location of this tree
        T['size'] = int(inputs[1])  # size of this tree: 0-3
        T['mine'] = inputs[2] != "0"  # 1 if this is your tree
        T['dormant'] = inputs[3] != "0"  # 1 if this tree is dormant
        TREE.append(T)
        if T['mine']:
            MY_TREE.append(T)
        else:
            OP_TREE.append(T)

    P_MOVE = int(input())
    P_MOVES = []
    for i in range(P_MOVE):
        P_MOVES.append(input())
    
    status = dict()
    status['DAY'] = DAY
    status['TIME'] = TIME
    status['NUTRIENTS'] = NUTRIENTS
    status['SUN'] = SUN
    status['SCORE'] = SCORE
    status['OPP_SUN'] = OPP_SUN
    status['OPP_SCORE'] = OPP_SCORE
    status['OPP_WAITING'] = OPP_WAITING
    status['N_TREES'] = N_TREES
    status['TREE'] = TREE
    status['MY_TREE'] = MY_TREE
    status['OP_TREE'] = OP_TREE
    status['P_MOVE'] = P_MOVE
    status['P_MOVES'] = P_MOVES
    return status

def run(status):
    DAY = status['DAY'] 
    TIME = status['TIME'] 
    NUTRIENTS = status['NUTRIENTS'] 
    SUN = status['SUN'] 
    SCORE = status['SCORE'] 
    OPP_SUN = status['OPP_SUN'] 
    OPP_SCORE = status['OPP_SCORE'] 
    OPP_WAITING = status['OPP_WAITING'] 
    N_TREES = status['N_TREES'] 
    TREE = status['TREE'] 
    MY_TREE = status['MY_TREE'] 
    OP_TREE = status['OP_TREE'] 
    P_MOVE = status['P_MOVE'] 
    P_MOVES = status['P_MOVES'] 

    ################ Main Code Start ####################
    TREE_POWER0 = sum([M['size'] for M in MY_TREE])
    TREE_POWER1 = sum([M['size'] for M in OP_TREE])
    print("TREE POWER:", TREE_POWER0, TREE_POWER1, file=sys.stderr, flush=True)

    SEED = []
    GROW = []
    COMPLETE = []
    for p in P_MOVES:
        ps = p.split()
        if 'SEED' in ps:
            p = {'from':int(ps[1]), 'to':int(ps[2])}
            SEED.append(p)
        elif 'GROW' in ps:
            idx = int(ps[1])
            size = sizeOf(MY_TREE, idx)
            GROW.append({'idx':idx, 'size':size})

        elif 'COMPLETE' in ps:
            COMPLETE.append(p)
    SEED.sort(key=lambda x:x['to'])
    if DAY < 16:
        GROW.sort(key=lambda x:x['size'], reverse=True)
        GROW.sort(key=lambda x:x['idx'])
    else:
        GROW.sort(key=lambda x:x['idx'])
        GROW.sort(key=lambda x:x['size'], reverse=True)

    pprint(SEED)
    pprint(GROW)
    pprint(COMPLETE)

    #      seed, grow, com, wait
    weight = [0, 5, 0, 2]
    if DAY < 1:
        weight = [0, 8, 0, 1]
    elif DAY < 3:
        weight = [3, 8, 0, 1]
    elif DAY < 6:
        weight = [5, 5, 0, 1]
    elif DAY < 16:
        weight = [2, 7, 0, 1]
    elif DAY < 22:
        weight = [0, 4, 6, 1]
    else:
        weight = [0, 3, 9, 1]
    weight[0] = weight[0] if len(SEED)     != 0 else 0
    weight[1] = weight[1] if len(GROW)     != 0 else 0
    weight[2] = weight[2] if len(COMPLETE) != 0 else 0
    weight[3] = weight[3]/SUN if SUN != 0 else 1

    total_weight = sum(weight)
    for i, w in enumerate(weight):
        weight[i] = w/total_weight
    for i, w in enumerate(weight[1:]):
        weight[i+1] = weight[i] + weight[i+1]
    
    pprint(weight)

    r = random.random()
    if r < weight[0]:
        if(len(SEED) == 0):
            cmd = "WAIT"
        else:
            # d = random.randint(0, len(SEED)-1)
            cmd = "SEED %d %d" % (SEED[0]['from'], SEED[0]['to'])
    elif r < weight[1]:
        if(len(GROW) == 0):
            cmd = "WAIT"
        else:
            # d = random.randint(0, len(GROW)-1)
            cmd = "GROW %d" % (GROW[0]['idx'])
    elif r < weight[2]:
        if(len(COMPLETE) == 0):
            cmd = "WAIT"
        else:
            d = random.randint(0, len(COMPLETE)-1)
            cmd = COMPLETE[d]
    else:
        cmd = "WAIT"
    print(cmd, cmd)
    ################ Main Code End   ####################

def pprint(s):
    print(s, file=sys.stderr, flush=True)

def sizeOf(TREE, idx):
    for t in TREE:
        if t['idx'] == idx:
            return t['size']

## MAIN Program 
MAP = getInputDefault()
# Main Game Loop
while True:
    status = getInput()
    run(status)
## MAIN Program End
